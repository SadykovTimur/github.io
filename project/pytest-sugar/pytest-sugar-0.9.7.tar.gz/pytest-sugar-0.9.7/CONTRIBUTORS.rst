The following people have contributed to pytest-sugar:

* Janne Vanhala
* Teemu
* Marc Abramowitz
* Yizhe Tang
* Mahdi Yusuf
* dscerri
* Mounier Florian
* Balthazar Rouberol
* Michael Howitz
